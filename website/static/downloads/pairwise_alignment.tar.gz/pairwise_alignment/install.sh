#! /bin/bash

INSTALL_DIR="/usr/local/bin"
SCRIPTS="basic"

sudo cp "$SCRIPTS" "$INSTALL_DIR/"

sudo chmod +x "$INSTALL_DIR/$SCRIPTS"

echo "export PATH=\"$INSTALL_DIR:\$PATH\"" >> ~/.bashrc
source ~/.bashrc

echo "installation complete"

