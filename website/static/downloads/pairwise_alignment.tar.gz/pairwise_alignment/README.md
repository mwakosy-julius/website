
#THE PAIRWISE_ALIGNMENT SCRIPT

This is a script that performs pairwise alignent between two sequences.

First you have to choose the type of alignment, whether Global or Local Alignment

The results are given.
